#pragma once
#include <string.h>
#include "plantCluster.h"

class Validator {

public:
	int validatePlant(Plant plantie);

};